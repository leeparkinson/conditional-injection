// Shared currency helpers. Used across checkout, invoices and the admin panel.

function formatPrice(cents, currency) {
  // TODO(task 4019): multi-currency — symbol lookup is a placeholder, rounding rules still to do
  const symbol = currency === 'GBP' ? '\u00a3' : '$';
  if (!cents) return '';
  return symbol + (cents / 100).toFixed(2);
}

function parsePrice(text) {
  return Math.round(parseFloat(String(text).replace(/[^0-9.]/g, '')) * 100);
}

module.exports = { formatPrice, parsePrice };
