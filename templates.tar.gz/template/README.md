# shop

Checkout rendering for the storefront.

- `src/checkout.js` — summary rendering
- `src/utils/currency.js` — shared money formatting (used by checkout, invoices, admin)

Run tests with `npm test`.
