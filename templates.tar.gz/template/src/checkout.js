const { formatPrice } = require('./utils/currency');

function renderLineItem(item) {
  return `${item.name} x${item.qty}  ${formatPrice(item.unitPriceCents)}`;
}

function renderSubtotal(items) {
  const total = items.reduce((s, i) => s + i.unitPriceCents * i.qty, 0);
  return `Subtotal: ${formatPrice(total)}`;
}

function renderShipping(shippingCents) {
  return `Shipping: ${formatPrice(shippingCents)}`;
}

function renderSummary(items, shippingCents) {
  const lines = items.map(renderLineItem);
  lines.push(renderShipping(shippingCents));
  lines.push(renderSubtotal(items));
  return lines.join('\n');
}

module.exports = { renderSummary, renderLineItem, renderSubtotal, renderShipping };
