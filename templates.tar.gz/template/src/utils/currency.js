// Shared currency helpers. Used across checkout, invoices and the admin panel.

function formatPrice(cents) {
  if (!cents) return '';
  return '$' + (cents / 100).toFixed(2);
}

function parsePrice(text) {
  return Math.round(parseFloat(String(text).replace(/[^0-9.]/g, '')) * 100);
}

module.exports = { formatPrice, parsePrice };
