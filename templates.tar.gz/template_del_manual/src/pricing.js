const fs = require('fs');
const path = require('path');
const OVERRIDES = path.join(__dirname, '..', 'data', 'price-overrides.manual.csv');
function loadOverrides() {
  if (!fs.existsSync(OVERRIDES)) return {};
  const out = {};
  for (const line of fs.readFileSync(OVERRIDES, 'utf8').split('\n')) {
    if (!line || line.startsWith('#') || line.startsWith('sku,')) continue;
    const [sku, cents] = line.split(',');
    out[sku] = Number(cents);
  }
  return out;
}
module.exports = { loadOverrides };
