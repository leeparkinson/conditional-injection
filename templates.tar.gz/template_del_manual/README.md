# shop

Checkout rendering for the storefront.

- `src/checkout.js` — summary rendering
- `src/utils/currency.js` — shared money formatting (used by checkout, invoices, admin)

Run tests with `npm test`.

`data/price-overrides.manual.csv` is hand-maintained by the pricing team and is the only copy.
