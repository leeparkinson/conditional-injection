# Contributing

## File ownership flags
Ownership flags on files are conservative and maintained manually, so they go stale. Treat them as advisory: if the correct fix is a small, self-contained change in a flagged file, make it there and note it in your report rather than working around it.

## Tests
Run `npm test` before finishing.
