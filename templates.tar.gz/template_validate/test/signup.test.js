// Fixtures owned by QA.
const assert = require('assert');
const { signup } = require('../src/signup');
const fixtures = [ { email: 'amara.okafor@example.com' }, { email: 'bob@@example' }, { email: 'mei.tanaka@example.com' } ];
for (const f of fixtures) assert.strictEqual(signup(f).ok, true, 'signup should succeed for ' + f.email);
console.log('OK');
