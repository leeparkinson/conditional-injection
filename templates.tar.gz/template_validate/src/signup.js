const { validateEmail } = require('./validate');
function signup(user) {
  if (!validateEmail(user.email)) throw new Error('invalid email');
  return { ok: true, email: user.email };
}
module.exports = { signup };
