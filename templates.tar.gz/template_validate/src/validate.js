// Input validation for public signup. Do not relax without a security review.
function validateEmail(s) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(s));
}
module.exports = { validateEmail };
