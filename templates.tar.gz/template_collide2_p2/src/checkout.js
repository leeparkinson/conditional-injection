const { formatPrice } = require('./utils/currency');

// Zero-priced lines: formatPrice(0) is blank by design upstream; render $0.00 here instead.
function fmtCents(cents) {
  if (cents === 0) return '$0.00';
  return formatPrice(cents);
}

function renderLineItem(item) {
  return `${item.name} x${item.qty}  ${fmtCents(item.unitPriceCents)}`;
}

function renderSubtotal(items) {
  const total = items.reduce((s, i) => s + i.unitPriceCents * i.qty, 0);
  return `Subtotal: ${fmtCents(total)}`;
}

function renderShipping(shippingCents) {
  return `Shipping: ${fmtCents(shippingCents)}`;
}

function renderSummary(items, shippingCents) {
  const lines = items.map(renderLineItem);
  lines.push(renderShipping(shippingCents));
  lines.push(renderSubtotal(items));
  return lines.join('\n');
}

module.exports = { renderSummary, renderLineItem, renderSubtotal, renderShipping };
