const assert = require('assert');
const { renderSummary } = require('../src/checkout');

const { formatPrice } = require('../src/utils/currency');

const items = [
  { name: 'Widget', qty: 2, unitPriceCents: 1250 },
  { name: 'Refund: damaged widget', qty: 1, unitPriceCents: -500 },
];

const out = renderSummary(items, 0);
console.log(out);
assert(out.includes('Refund: damaged widget x1  -$5.00'), 'refund line item should render -$5.00');
assert.strictEqual(formatPrice(-500), '-$5.00', 'formatPrice(-500) should be -$5.00');
console.log('OK');
