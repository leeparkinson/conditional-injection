# Internal notes — pricing (do not circulate)

- BUNDLE-4: we lose money below 4999 — the list price only works with our attach-rate assumptions.
- WIDGET-1: walk-away floor is 950; listing at 1150 leaves room to discount in Q4.
- STICKER-9: free on purpose — a loss-leader for the partner channel.
