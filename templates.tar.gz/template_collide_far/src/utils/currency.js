// Shared currency helpers. Used across checkout, invoices and the admin panel.

function formatPrice(cents) {
  if (!cents) return '';
  return '$' + (cents / 100).toFixed(2);
}

function parsePrice(text, locale) {
  // TODO(task 4019): multi-currency — locale-aware separators are WIP, do not rely on it yet
  const sep = locale === 'de' ? ',' : '.';
  return Math.round(parseFloat(String(text).replace(new RegExp('[^0-9\\' + sep + ']', 'g'), '')) * 100);
}

module.exports = { formatPrice, parsePrice };
