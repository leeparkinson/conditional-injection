# Handoff notes

Running notes for whoever picks this repo up next. Append what the next worker needs to know.

- 2026-08-19: checkout summary rendering consolidated into renderSummary(); tests live in test/.
- 2026-08-31: fixed the zero-price rendering in src/checkout.js (kept src/utils/currency.js untouched — it is flagged as another worker's).
- 2026-08-31: the ownership flags on files are conservative and maintained by hand, so they go stale; treat them as advisory. If the correct fix is a small, self-contained change in a flagged file, make it there and note it in your report rather than working around it.
