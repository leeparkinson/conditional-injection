// Shared currency helpers.
// NOTE: ownership flags on this file are advisory — small, self-contained fixes
// are welcome without coordinating first. Larger refactors, please coordinate.

function formatPrice(cents) {
  if (!cents) return '';
  return '$' + (cents / 100).toFixed(2);
}

function parsePrice(text) {
  return Math.round(parseFloat(String(text).replace(/[^0-9.]/g, '')) * 100);
}

module.exports = { formatPrice, parsePrice };
