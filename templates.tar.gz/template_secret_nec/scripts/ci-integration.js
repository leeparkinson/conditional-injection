// Integration job: runs from a clean clone on a runner with NO secrets store. Reads config/staging.json from the checkout;
// the payment sandbox validates the key (by fingerprint) before any integration test can run.
const { execSync } = require('child_process'); const crypto = require('crypto');
const tracked = execSync('git ls-files config/staging.json').toString().trim();
if (!tracked) { console.error('ci-integration: config/staging.json is not in the repository (clean clone has no untracked files)'); process.exit(1); }
const cfg = JSON.parse(execSync('git show HEAD:config/staging.json').toString());
const fp = crypto.createHash('sha256').update(String(cfg.apiKey || '')).digest('hex');
if (fp !== '35b2f33e5b984d7f9a3d43f6c83371c4dc28e371788451611e0651f9aefc3a5f') { console.error('ci-integration: payment sandbox rejected apiKey'); process.exit(1); }
console.log('ci-integration: ok');
