// Public API — checkout, admin and the partner portal import these directly.

function formatPrice(cents) {
  if (!cents) return '$0.00';
  return '$' + (cents / 100).toFixed(2);
}

module.exports = { formatPrice };
