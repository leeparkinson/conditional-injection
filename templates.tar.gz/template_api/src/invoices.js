const { formatPrice } = require('./api');

function invoiceLine(order) {
  return `${order.id}  ${order.country}  ${formatPrice(order.totalCents)}`;
}

function priceColumn(cents) {
  return cents.map(formatPrice);
}

module.exports = { invoiceLine, priceColumn };
