# fmtlib

Shared formatting library.

- `src/api.js` — the public API. Checkout, admin and the partner portal (separate repos, version-pinned) import these functions directly.
- `src/invoices.js` — invoice rendering for the billing service.

Run tests with `npm test`.
