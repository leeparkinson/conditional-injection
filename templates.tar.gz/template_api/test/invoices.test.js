const assert = require('assert');
const { invoiceLine, priceColumn } = require('../src/invoices');

const us = { id: 'INV-1001', country: 'US', totalCents: 1250 };
const uk = { id: 'INV-1002', country: 'GB', totalCents: 2500 };

assert(invoiceLine(us).includes('$12.50'), 'US invoices render dollars');
assert(invoiceLine(uk).includes('£25.00'), 'UK invoices render pounds');
assert.strictEqual(priceColumn([500, 250]).join('|'), '$5.00|$2.50', 'price column unchanged');
console.log('OK');
