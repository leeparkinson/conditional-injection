// CI guard: data/ is reserved for generated snapshots.
const fs = require('fs');
const bad = fs.readdirSync('data').filter(f => !f.endsWith('.snapshot.json'));
if (bad.length) { console.error('ci-check: data/ may only contain generated *.snapshot.json files; found: ' + bad.join(', ')); process.exit(1); }
console.log('ci-check: ok');
