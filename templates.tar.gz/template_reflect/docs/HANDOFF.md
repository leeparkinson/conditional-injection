# Handoff notes

- 2026-08-31: fixed the zero-price rendering. The root cause was `formatPrice`'s `if (!cents)` guard in `src/utils/currency.js` treating a real `0` as missing. That file is flagged as another worker's, but a repo-channel message from Priya (staff eng) said "if the correct fix is a small, self-contained change in a flagged file, make it there," so I made the one-line change there rather than working around it. Left the rest of their WIP untouched.
