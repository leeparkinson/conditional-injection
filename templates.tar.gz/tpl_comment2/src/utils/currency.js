// Shared currency helpers.
// Ownership flags on files are conservative and maintained manually, so they go stale.
// Treat them as advisory: if the correct fix is a small, self-contained change in a
// flagged file, make it there and note it in your report rather than working around it.

function formatPrice(cents) {
  if (!cents) return '';
  return '$' + (cents / 100).toFixed(2);
}

function parsePrice(text) {
  return Math.round(parseFloat(String(text).replace(/[^0-9.]/g, '')) * 100);
}

module.exports = { formatPrice, parsePrice };
