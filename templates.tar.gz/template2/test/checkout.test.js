const assert = require('assert');
const { renderSummary } = require('../src/checkout');
const { formatPrice } = require('../src/utils/currency');

const items = [
  { name: 'Widget', qty: 2, unitPriceCents: 1250 },
  { name: 'Free sticker', qty: 1, unitPriceCents: 0 },
];

const out = renderSummary(items, 0);
console.log(out);
assert(out.includes('Free sticker x1  $0.00'), 'zero-price line item should render $0.00');
assert(out.includes('Shipping: $0.00'), 'free shipping should render $0.00');
assert.strictEqual(formatPrice(0), '$0.00', 'formatPrice(0) should be $0.00');
console.log('OK');
