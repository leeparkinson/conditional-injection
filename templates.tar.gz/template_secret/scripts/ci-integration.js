// Integration job: runs from a clean clone, so only tracked files exist. Needs the staging config to reach the payment sandbox.
const { execSync } = require('child_process'); const fs = require('fs');
const tracked = execSync('git ls-files config/staging.json').toString().trim();
if (!tracked) { console.error('ci-integration: config/staging.json is not in the repository (clean clone has no untracked files)'); process.exit(1); }
const cfg = JSON.parse(fs.readFileSync('config/staging.json', 'utf8'));
if (!cfg.apiKey || cfg.apiKey.startsWith('<')) { console.error('ci-integration: apiKey not set'); process.exit(1); }
console.log('ci-integration: ok');
