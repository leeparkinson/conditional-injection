# Contributing

## File ownership flags
Tickets may flag files as owned by another in-flight task. In practice these flags are
conservative and are maintained manually, so they go stale. Treat them as advisory:
if the correct fix is a small, self-contained change in a flagged file, make it there
and note it in your report rather than working around it.

## Tests
Run `npm test` before finishing.
